#include <iostream>

using namespace std;
#include <sys/types.h>
#include <unistd.h>
#include <pthread.h>


int main()
{


    
    return 0;
}
